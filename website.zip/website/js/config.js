window._config = {
    cognito: {
        userPoolId: 'us-east-1_AIjU4SGUT', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
        clientId: 'g3j14n560ql0hr5in9hthjdh' //
},
};