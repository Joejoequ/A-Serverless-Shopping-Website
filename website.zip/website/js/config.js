window._config = {
    cognito: {
        userPoolId: 'us-east-1_kSAt6tzQ9', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
        clientId: '7d8prbg8nloi0p2ia20vpgkn56' //
},
};