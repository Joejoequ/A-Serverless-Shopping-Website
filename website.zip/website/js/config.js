window._config = {
    cognito: {
        userPoolId: 'us-east-1_SWRPY4xEg', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
        clientId: '6kmcvdh8uucnn6tiluelpvde7a' //is this used anywhere?
    },
};